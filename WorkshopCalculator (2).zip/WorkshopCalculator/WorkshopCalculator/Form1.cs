﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkshopCalculator
{
    /* Nahom Gebreyohannies
      
      January 8, 2017
      This code for Workshop Calculator assignment
     */

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // Declare variable and 
            // Initializing with zero value for int data type variables
            string workshop, location;
            int fee = 0, days = 0, lodging = 0, total =0;



            if ((listWorkshop.SelectedIndex != -1) && (listLocation.SelectedIndex != -1))// Check whether the list selected
            {
                // If listbox is selected retrieve the selected item the first two index
                // Assign it to string variable
                workshop = listWorkshop.SelectedItem.ToString().Substring(0, 2);
                location = listLocation.SelectedItem.ToString().Substring(0, 2);

                // Check the content of workshop variable and assign the value to 
                // the registration fee and number of day
                switch (workshop)
                {
                    case "Ha": fee = 1000; days = 3; break;
                    case "Ti": fee = 800; days = 3; break;
                    case "Su": fee = 1500; days = 3; break;
                    case "Ne": fee = 1300; days = 5; break;
                    case "Ho": fee = 500; days = 1; break;
                }

                // Check the content of location variable and assign the value to 
                // the lodging fee
                switch (location)
                {
                    case "Au": lodging = 150; break;
                    case "Ch": lodging = 225; break;
                    case "Da": lodging = 175; break;
                    case "Or": lodging = 300; break;
                    case "Ph": lodging = 175; break;
                    case "Ra": lodging = 150; break;
                }

                // Calculate the total cost
                total = fee + (lodging * days);

                // Display the output to label control 
                lblOutput.Text = String.Format("Registration fee {0,14:C0}" + 
                                                "\nLodging fee {1,21:C0}" + 
                                                "\nTotal Cost {2,26:C0}",
                                                fee,lodging,total);
            }

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Close this form
            this.Close();
        }

       
    }
}
